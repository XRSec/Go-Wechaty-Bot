import { VERSION }    from './config.js'
import { PuppetXp }   from './puppet-xp.js'

export {
  VERSION,
  PuppetXp,
}
export default PuppetXp
