import codeRootPkg from '../commonjs/code-root.js'
const codeRoot = codeRootPkg['codeRoot']

export {
  codeRoot,
}
