export declare const codeRoot: string
