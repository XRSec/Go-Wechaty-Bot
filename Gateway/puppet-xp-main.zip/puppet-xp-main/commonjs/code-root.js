const path = require('path')

const codeRoot = path.join(
  __dirname,
  '..',
)

module.exports = {
  codeRoot,
}
